﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WPF_ImageFind_2017
{
    /// <summary>
    /// App.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class App : Application
    {
        private static Screen.MainWindow _mainview;
        public static Screen.MainWindow MainView
        {
            get
            {
                if (_mainview == null)
                {
                    _mainview = new Screen.MainWindow();
                }

                return _mainview;
            }
        }
        private static Base.FBaseFunc _base;
        public static Base.FBaseFunc Base
        {
            get
            {
                if (_base == null)
                {
                    _base = new Base.FBaseFunc();
                }

                return _base;
            }
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            MainView.Show();
            Base.InitializeSystem();
        }

        public static void Close()
        {
            Base.CloseThread();
            Current.Shutdown();
        }
    }
}
