﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using WPF_ImageFind_2017.Data;

namespace WPF_ImageFind_2017.Screen.Sub
{
    public class SubWindowViewModel : INotifyPropertyChanged
    {
        private bool _mouseDown;
        private bool _getImg;
        private double _xPos;
        private double _yPos;
        private ImageSource _imageData;
        private ImageSource _targetData;
        private System.Drawing.Point _start;
        private System.Drawing.Point _end;

        public SubWindowViewModel()
        {
            SaveCommand = new CommandImpl(SaveEvent);
            ExitCommand = new CommandImpl(ExitEvent);
            MouseUpCommand = new CommandImpl(MouseUpEvent);
            MouseDownCommand = new CommandImpl(MouseDownEvent);
            MouseMoveCommand = new CommandImpl(MouseMoveEvent);
            TargetData = App.Base.GetTargetSource();
        }
        public double XPos
        {
            get => _xPos;
            set
            {
                _xPos = value;
                OnPropertyChanged();
            }
        }
        public double YPos
        {
            get => _yPos;
            set
            {
                _yPos = value;
                OnPropertyChanged();
            }
        }
        public ImageSource ImageData
        {
            get => _imageData;
            set
            {
                _imageData = value;
                OnPropertyChanged();
            }
        }
        public ImageSource TargetData
        {
            get => _targetData;
            set
            {
                _targetData = value;
                OnPropertyChanged();
            }
        }
        public ICommand SaveCommand { get; }
        public ICommand ExitCommand { get; }
        public ICommand MouseUpCommand { get; }
        public ICommand MouseDownCommand { get; }
        public ICommand MouseMoveCommand { get; }

        public void SetImageSource(ImageSource data)
        {
            ImageData = data;
        }

        private void SaveEvent(object obj)
        {
            App.Base.SaveTargetImage(TargetData);

            var window = obj as Window;
            if (window == null)
            {
                return;
            }

            window.Close();
        }
        private void ExitEvent(object obj)
        {
            var window = obj as Window;
            if (window == null)
            {
                return;
            }

            window.Close();
        }
        private void MouseUpEvent(object obj)
        {
            _mouseDown = false;
            _getImg = true;
            if (_end == null)
            {
                _end = new System.Drawing.Point((int)XPos, (int)YPos);
            }
            else
            {
                _end.X = (int)XPos;
                _end.Y = (int)YPos;
            }
        }
        private void MouseDownEvent(object obj)
        {
            _mouseDown = true;
            _getImg = false;
            if (_start == null)
            {
                _start = new System.Drawing.Point((int)XPos, (int)YPos);
            }
            else
            {
                _start.X = (int)XPos;
                _start.Y = (int)YPos;
            }
        }
        private void MouseMoveEvent(object obj)
        {
            if (_getImg)
            {
                DrawSub();
                _getImg = false;
            }
            else if (_mouseDown)
            {
                DrawSub((int)XPos, (int)YPos);
            }
        }
        private void DrawSub(int xPos = 0, int yPos = 0)
        {
            if (ImageData == null)
            {
                return;
            }

            var subBit = new Bitmap(App.Base.BitmapFromImageSource(ImageData));
            int xStart = 0, yStart = 0, width = 1, height = 1;
            if (_getImg)
            {
                if (_start.X > _end.X)
                {
                    xStart = _end.X;
                    width = _start.X - _end.X;
                }
                else if (_start.X < _end.X)
                {
                    xStart = _start.X;
                    width = _end.X - _start.X;
                }
                else if (_start.X == _end.X)
                {
                    return;
                }
                else if (_start.X < 0 || xPos < 0)
                {
                    return;
                }

                if (_start.Y > _end.Y)
                {
                    yStart = _end.Y;
                    height = _start.Y - _end.Y;
                }
                else if (_start.Y < _end.Y)
                {
                    yStart = _start.Y;
                    height = _end.Y - _start.Y;
                }
                else if (_start.Y == _end.Y)
                {
                    return;
                }
                else if (_start.Y < 0 || yPos < 0)
                {
                    return;
                }

                if (width > height)
                {
                    height = width;
                }
                else if (width <= height)
                {
                    width = height;
                }

                if (ImageData.Width < width + xStart || ImageData.Height < height + yStart)
                {
                    return;
                }
                subBit = subBit.Clone(new Rectangle(xStart, yStart, width, height), System.Drawing.Imaging.PixelFormat.DontCare);
                TargetData = App.Base.ImageSourceFromBitmap(subBit);
            }
            else if (_mouseDown)
            {
                if (_start.X > xPos)
                {
                    xStart = xPos;
                    width = _start.X - xPos;
                }
                else if (_start.X < xPos)
                {
                    xStart = _start.X;
                    width = xPos - _start.X;
                }
                else if (_start.X == xPos)
                {
                    return;
                }
                else if (_start.X < 0 || xPos < 0)
                {
                    return;
                }

                if (_start.Y > yPos)
                {
                    yStart = yPos;
                    height = _start.Y - yPos;
                }
                else if (_start.Y < yPos)
                {
                    yStart = _start.Y;
                    height = yPos - _start.Y;
                }
                else if (_start.Y == yPos)
                {
                    return;
                }
                else if (_start.Y < 0 || yPos < 0)
                {
                    return;
                }

                if (width > height)
                {
                    height = width;
                }
                else if (width <= height)
                {
                    width = height;
                }

                if (ImageData.Width < width + xStart || ImageData.Height < height + yStart)
                {
                    return;
                }

                subBit = subBit.Clone(new Rectangle(xStart, yStart, width, height), System.Drawing.Imaging.PixelFormat.DontCare);
                TargetData = App.Base.ImageSourceFromBitmap(subBit);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
