﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using WPF_ImageFind_2017.Data;

namespace WPF_ImageFind_2017.Screen
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private DispatcherTimer _timer;
        private ImageSource _imageData;
        private ImageSource _sagakData;
        public MainWindowViewModel()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(10);
            _timer.Tick += new EventHandler(Timer_Tick);
            _timer.IsEnabled = true;

            FindCommand = new CommandImpl(FindEvent);
            SetCommand = new CommandImpl(SetEvent);
            ExitCommand = new CommandImpl(ExitEvent);
        }

        public ImageSource ImageData
        {
            get => _imageData;
            set
            {
                _imageData = value;
                OnPropertyChanged();
            }
        }
        public ImageSource SagakData
        {
            get => _sagakData;
            set
            {
                _sagakData = value;
                OnPropertyChanged();
            }
        }
        public ICommand FindCommand { get; }
        public ICommand SetCommand { get; }
        public ICommand ExitCommand { get; }
        public ICommand ClosingCommand { get; }

        private void FindEvent(object obj)
        {
            SagakData = App.Base.ImageSourceFromBitmap(App.Base.SearchImage());
        }
        private void SetEvent(object obj)
        {
            var dlg = new Sub.SubWindow();
            dlg.SetImageSource(ImageData);
            dlg.ShowDialog();
        }
        private void ExitEvent(object obj)
        {
            DestroyWPF((Window)obj);
            App.Close();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            ImageData = App.Base.GetImageSource();
        }
        public void SetMessageHook(Window mother)
        {
            HwndSource hwndSource = PresentationSource.FromVisual(mother) as HwndSource;
            if (hwndSource != null)
            {
                hwndSource.AddHook(new HwndSourceHook(this.HookingFunc));
            }
        }
        public IntPtr HookingFunc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == 0x10)
            {
                handled = true;
            }
            return IntPtr.Zero;
        }
        public void IHaveToCloseThis(object sender, MainWindow mother)
        {
            var parent = FindParent<MainWindow>(sender as Button);
            if (parent == null)
            {
                parent = mother;
            }
            HwndSource hwndSource = PresentationSource.FromVisual(parent as Visual) as HwndSource;
            if (hwndSource != null)
            {
                hwndSource.RemoveHook(new HwndSourceHook(HookingFunc));
            }
            Window.GetWindow(mother).Close();
        }
        private static T FindParent<T>(DependencyObject dependencyObject) where T : DependencyObject
        {
            var parent = VisualTreeHelper.GetParent(dependencyObject);
            if (parent == null)
            {
                return null;
            }

            var parentT = parent as T;
            return parentT ?? FindParent<T>(parent);
        }
        public void DestroyWPF(Visual mother)
        {
            HwndSource hwndSource = PresentationSource.FromVisual(mother) as HwndSource;
            if (hwndSource != null)
            {
                hwndSource.RemoveHook(new HwndSourceHook(HookingFunc));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
