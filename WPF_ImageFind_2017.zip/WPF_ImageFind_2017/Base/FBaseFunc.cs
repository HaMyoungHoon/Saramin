﻿using BaseLib_2017_net48;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WPF_ImageFind_2017.Base
{
    public class FBaseFunc : FThread
    {
        [DllImport("User32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")]
        internal static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, int nFlags);
        [DllImport("gdi32.dll", EntryPoint = "DeleteObject")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DeleteObject([In] IntPtr hObject);

        public bool IsPolling { get; set; }
        public Bitmap ProcessData { get; private set; }
        public string Score { get; private set; }
        public const string TARGET_PATH = @".\Target.png";
        public FBaseFunc()
        {
            SetThreadInterval(eTHREAD.TH1, 1000 / 60);
        }

        public void InitializeSystem()
        {
            IsPolling = true;
            CreateThread(eTHREAD.TH1);
        }

        public override bool ProcThread1()
        {
            if (IsPolling)
            {
                DrawProgram();
            }

            return true;
        }

        public ImageSource GetImageSource()
        {
            if (ProcessData == null)
            {
                return null;
            }
            return ImageSourceFromBitmap(ProcessData);
        }
        public ImageSource GetTargetSource()
        {
            if (File.Exists(TARGET_PATH))
            {
                return ImageSourceFromBitmap(new Bitmap(TARGET_PATH));
            }

            return null;
        }
        public void SaveTargetImage(ImageSource data)
        {
            if (data == null)
            {
                return;
            }

            var buffer = BitmapFromImageSource(data);
            buffer.Save(TARGET_PATH, System.Drawing.Imaging.ImageFormat.Png);
        }
        public ImageSource ImageSourceFromBitmap(Bitmap bmp)
        {
            var handle = bmp.GetHbitmap();
            try
            {
                return Imaging.CreateBitmapSourceFromHBitmap(handle, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            }
            finally { DeleteObject(handle); }
        }
        public Bitmap BitmapFromImageSource(ImageSource img)
        {
            var bitmapSource = (BitmapSource)img;

            int width = bitmapSource.PixelWidth;
            int height = bitmapSource.PixelHeight;
            int stride = width * ((bitmapSource.Format.BitsPerPixel + 7) / 8);
            IntPtr ptr = IntPtr.Zero;
            try
            {
                ptr = Marshal.AllocHGlobal(height * stride);
                bitmapSource.CopyPixels(new Int32Rect(0, 0, width, height), ptr, height * stride, stride);
                using (var bmp = new Bitmap(width, height, stride, System.Drawing.Imaging.PixelFormat.Format32bppRgb, ptr))
                {
                    return new Bitmap(bmp);
                }
            }
            finally
            {
                if (ptr != IntPtr.Zero)
                {
                    Marshal.FreeHGlobal(ptr);
                }
            }
        }
        public Bitmap SearchImage()
        {
            Bitmap findImage = new Bitmap(ProcessData.Width, ProcessData.Height);
            Bitmap targetImage;
            if (File.Exists(TARGET_PATH))
            {
                targetImage = new Bitmap(TARGET_PATH);
            }
            else
            {
                targetImage = new Bitmap(ProcessData.Width, ProcessData.Height);
            }
            try
            {
                using (Mat ScreenMat = OpenCvSharp.Extensions.BitmapConverter.ToMat(ProcessData))
                using (Mat FindMat = OpenCvSharp.Extensions.BitmapConverter.ToMat(targetImage))
                using (Mat res = ScreenMat.MatchTemplate(FindMat, TemplateMatchModes.CCoeffNormed))
                {
                    OpenCvSharp.Point minloc, maxloc;
                    double minval, maxval = 0;
                    Cv2.MinMaxLoc(res, out minval, out maxval, out minloc, out maxloc);
                    Score = maxval.ToString();
                    if (maxval > 0.6)
                    {
                        var bmp = new Bitmap(ProcessData.Width, ProcessData.Height);
                        using (Graphics g = Graphics.FromImage(bmp))
                        {
                            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Black, 1);
                            Rectangle rect = new Rectangle(maxloc.X, maxloc.Y, targetImage.Size.Width, targetImage.Height);
                            g.DrawRectangle(p, rect);
                        }
                        findImage = bmp;
                    }
                    else
                    {
                        var bmp = new Bitmap(ProcessData.Width, ProcessData.Height);
                        using (Graphics g = Graphics.FromImage(bmp))
                        {
                            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Transparent, 1);
                            g.DrawRectangle(p, 0, 0, 0, 0);
                        }
                        findImage = bmp;
                    }
                }
            }
            catch
            {

            }

            return findImage.Clone() as Bitmap;
        }
        private void DrawProgram()
        {
//            IntPtr findWindow = FindWindow(null, "하스스톤");
            IntPtr findWindow = FindWindow(null, "카카오톡");
            if (findWindow != IntPtr.Zero)
            {
                Graphics graphics = Graphics.FromHwnd(findWindow);
                graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                var rect = Rectangle.Round(graphics.VisibleClipBounds);
                if (rect.Width == 0 && rect.Height == 0)
                {
                    return;
                }
                var bmp = new Bitmap(rect.Width, rect.Height);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    IntPtr hdc = g.GetHdc();
                    PrintWindow(findWindow, hdc, 0x02);
                    g.ReleaseHdc(hdc);
                }

                ProcessData = bmp.Clone() as Bitmap;
            }
        }
    }
}
